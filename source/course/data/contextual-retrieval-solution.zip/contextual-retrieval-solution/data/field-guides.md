# aurora-v1 | Aurora Sensor, version 1 field guide

The Aurora Sensor version 1 uses the amber status lamp to indicate that the battery is charging. Charging normally takes four hours.

If code AX-14 appears during calibration, keep the probe dry and restart the calibration sequence after ten minutes.

The device records one temperature sample every 30 seconds. Measurements remain on the device for seven days.

# aurora-v2 | Aurora Sensor, version 2 field guide

The Aurora Sensor version 2 uses the amber status lamp to indicate a network connection problem. Check the gateway and reconnect the sensor.

If code AX-14 appears during calibration, replace the probe seal before restarting the calibration sequence.

The device records one temperature sample every 10 seconds. Measurements remain on the device for 30 days.

# boreal-v1 | Boreal Gateway, version 1 field guide

The Boreal Gateway version 1 uses a blue status lamp to show that its radio link is healthy. The gateway supports up to 12 sensors.

If code BG-27 appears, clear the radio channel and reboot the gateway. A steady blue lamp confirms recovery.

The device stores readings locally for 48 hours during an outage, then forwards them when its connection returns.

# boreal-v2 | Boreal Gateway, version 2 field guide

The Boreal Gateway version 2 uses a green status lamp to show that its radio link is healthy. The gateway supports up to 40 sensors.

If code BG-27 appears, update the radio firmware before rebooting the gateway. A steady green lamp confirms recovery.

The device stores readings locally for 96 hours during an outage, then forwards them when its connection returns.
