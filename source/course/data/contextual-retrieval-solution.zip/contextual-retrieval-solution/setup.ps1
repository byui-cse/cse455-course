param([switch]$Gpu)

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$composeArgs = @('compose', '-f', 'compose.yaml')
if ($Gpu) { $composeArgs += @('-f', 'compose.gpu.yaml') }
docker @composeArgs up -d --wait
if ($LASTEXITCODE -ne 0) { throw 'Could not start the containers. Is Docker Desktop running?' }
$ready = $false
for ($i = 0; $i -lt 30; $i++) {
    docker @composeArgs exec -T ollama ollama list 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { $ready = $true; break }
    Start-Sleep -Seconds 2
}
if (-not $ready) { throw 'Ollama did not become ready. Check docker compose logs ollama.' }
docker @composeArgs exec -T ollama ollama pull all-minilm:22m
if ($LASTEXITCODE -ne 0) { throw 'Embedding model download failed.' }
docker @composeArgs exec -T ollama ollama pull qwen3:1.7b
if ($LASTEXITCODE -ne 0) { throw 'Language model download failed.' }
Write-Host 'Containers and models are ready. Continue with the README.'
