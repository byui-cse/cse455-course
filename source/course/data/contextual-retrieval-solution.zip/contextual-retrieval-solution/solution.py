"""Reference implementations for the exercises. See starter.py for the tasks."""
import math
import re
from collections import Counter


def split_documents(markdown):
    """Split at document headings and blank paragraphs; preserve the whole document."""
    documents = re.split(r"(?m)^# ", markdown.strip())
    chunks = []
    for doc in filter(None, documents):
        header, body = doc.split("\n", 1)
        doc_id, title = (part.strip() for part in header.split(" | ", 1))
        paragraphs = [p.strip().replace("\n", " ") for p in re.split(r"\n\s*\n", body) if p.strip()]
        full_document = f"{title}\n\n" + "\n\n".join(paragraphs)
        for number, paragraph in enumerate(paragraphs, 1):
            chunks.append({"id": f"{doc_id}-{number}", "document": full_document,
                           "title": title, "text": paragraph})
    return chunks


def contextualize(document, chunk, generate, prompt):
    """Ask a local model to situate a chunk, using the complete source document."""
    context = generate(prompt.format(document=document, chunk=chunk)).strip()
    if not context:
        raise ValueError("The model returned an empty context. Try a different local model.")
    return context


def tokenize(text):
    # Keep identifiers such as AX-14 as a single searchable term.
    return re.findall(r"[a-z0-9]+(?:-[a-z0-9]+)*", text.lower())


def bm25(query, rows, contextual=False):
    """Return IDs and BM25 scores. Uses the positive, smoothed IDF variant."""
    tokens = [tokenize((row['context'] + "\n" if contextual else "") + row['text']) for row in rows]
    if not tokens:
        return []
    counts = [Counter(t) for t in tokens]
    average_length = sum(map(len, tokens)) / len(tokens)
    query_terms = set(tokenize(query))
    rankings = []
    for row, words, frequencies in zip(rows, tokens, counts):
        score = 0.0
        for term in query_terms:
            frequency = frequencies[term]
            if not frequency:
                continue
            document_frequency = sum(term in c for c in counts)
            inverse_frequency = math.log(1 + (len(rows) - document_frequency + 0.5) / (document_frequency + 0.5))
            length_factor = 1.5 * (1 - 0.75 + 0.75 * len(words) / average_length)
            score += inverse_frequency * frequency * 2.5 / (frequency + length_factor)
        if score > 0:
            rankings.append((row['id'], score))
    return sorted(rankings, key=lambda item: (-item[1], item[0]))


def fuse(rankings, k=60):
    """Reciprocal rank fusion combines ranks, not incompatible raw scores."""
    scores = {}
    for ranking in rankings:
        for rank, (chunk_id, _) in enumerate(ranking, 1):
            scores[chunk_id] = scores.get(chunk_id, 0) + 1 / (k + rank)
    return sorted(scores.items(), key=lambda item: (-item[1], item[0]))


def rerank(question, candidates, generate, prompt):
    """Use an LLM as a pointwise reranker; return the same rows sorted by score."""
    scored = []
    for row in candidates:
        passage = f"Context: {row['context']}\nOriginal passage: {row['text']}"
        response = generate(prompt.format(question=question, passage=passage))
        match = re.search(r"(?<!\d)(10|[0-9])(?!\d)", response)
        if not match:
            raise ValueError(f"Reranker returned no 0–10 score for {row['id']}: {response!r}")
        scored.append((row, int(match.group(1))))
    return sorted(scored, key=lambda item: -item[1])
