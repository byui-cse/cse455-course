"""Build the human-readable example document from the editable source data."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    documents = json.loads((ROOT / "data/documents.json").read_text(encoding="utf-8"))
    sections = []
    for doc in documents:
        sections.append(f"# {doc['id']} | {doc['title']}\n\n" + "\n\n".join(doc["paragraphs"]))
    target = ROOT / "data/field-guides.md"
    target.write_text("\n\n".join(sections) + "\n", encoding="utf-8")
    print(f"Wrote {target} ({len(documents)} documents)")


if __name__ == "__main__":
    main()
