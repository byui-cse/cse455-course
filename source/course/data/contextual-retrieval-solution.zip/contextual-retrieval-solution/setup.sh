#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ "$#" -gt 1 ] || { [ "$#" -eq 1 ] && [ "$1" != "--gpu" ]; }; then
  echo 'Usage: sh setup.sh [--gpu]' >&2
  exit 2
fi
if [ "$#" -eq 1 ]; then
  set -- compose -f compose.yaml -f compose.gpu.yaml
else
  set -- compose -f compose.yaml
fi
docker "$@" up -d --wait
ready=0
for i in $(seq 1 30); do
  if docker "$@" exec -T ollama ollama list >/dev/null 2>&1; then ready=1; break; fi
  sleep 2
done
if [ "$ready" -ne 1 ]; then echo 'Ollama did not become ready. Check docker compose logs ollama.' >&2; exit 1; fi
docker "$@" exec -T ollama ollama pull all-minilm:22m
docker "$@" exec -T ollama ollama pull qwen3:1.7b
echo 'Containers and models are ready. Continue with the README.'
