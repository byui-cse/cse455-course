"""Command-line runner shared by the student implementation and reference solution."""
import argparse
import importlib
import json
import os
import time
from pathlib import Path

import psycopg
from psycopg.rows import dict_row
import requests

ROOT = Path(__file__).resolve().parent
DB_URL = os.environ.get("LAB_DATABASE_URL", "postgresql://lab:lab@127.0.0.1:55432/contextual_lab")
OLLAMA_URL = os.environ.get("LAB_OLLAMA_URL", "http://127.0.0.1:11435").rstrip("/")
CHAT_MODEL = os.environ.get("LAB_CHAT_MODEL", "qwen2.5:0.5b")
EMBED_MODEL = "all-minilm:22m"  # 384 dimensions; matches the database schema
MODES = ("dense", "bm25", "hybrid", "context-dense", "context-bm25", "context-hybrid", "rerank")


def prompt(name):
    return (ROOT / "prompts" / f"{name}.txt").read_text(encoding="utf-8")


def api(path, payload):
    response = requests.post(f"{OLLAMA_URL}/api/{path}", json=payload, timeout=600)
    response.raise_for_status()
    return response.json()


def generate(text):
    result = api("generate", {"model": CHAT_MODEL, "prompt": text, "stream": False,
                              "options": {"temperature": 0, "num_predict": 100, "num_ctx": 2048}})
    return result["response"].strip()


def embed(texts):
    vectors = api("embed", {"model": EMBED_MODEL, "input": texts, "truncate": False})["embeddings"]
    if len(vectors) != len(texts) or any(len(v) != 384 for v in vectors):
        raise ValueError("Expected one 384-dimensional all-minilm:22m vector per input")
    return vectors


def vector_literal(vector):
    return "[" + ",".join(str(float(value)) for value in vector) + "]"


def open_db():
    return psycopg.connect(DB_URL, row_factory=dict_row)


def load_chunks(implementation):
    source = (ROOT / "data/field-guides.md").read_text(encoding="utf-8")
    chunks = implementation.split_documents(source)
    if not chunks:
        raise ValueError("No chunks were produced")
    return chunks


def ingest(implementation):
    chunks = load_chunks(implementation)
    ids = [chunk['id'] for chunk in chunks]
    if len(ids) != len(set(ids)):
        raise ValueError("Chunk IDs must be unique")
    # Finish expensive model work before replacing the existing index.
    for index, chunk in enumerate(chunks, 1):
        chunk['context'] = implementation.contextualize(chunk['document'], chunk['text'], generate, prompt("context"))
        print(f"Context {index}/{len(chunks)}: {chunk['id']}: {chunk['context']}", flush=True)
    raw = embed([chunk['text'] for chunk in chunks])
    contextual = embed([chunk['context'] + "\n" + chunk['text'] for chunk in chunks])
    with open_db() as conn:
        with conn.cursor() as cur:
            cur.execute("CREATE EXTENSION IF NOT EXISTS vector")
            cur.execute("""CREATE TABLE IF NOT EXISTS lab_chunks (
                id text PRIMARY KEY, title text NOT NULL, text text NOT NULL, context text NOT NULL,
                raw_vector vector(384) NOT NULL, contextual_vector vector(384) NOT NULL)""")
            cur.execute("DELETE FROM lab_chunks")
            for chunk, raw_vec, context_vec in zip(chunks, raw, contextual):
                cur.execute("""INSERT INTO lab_chunks VALUES (%s, %s, %s, %s, %s::vector, %s::vector)""",
                            (chunk['id'], chunk['title'], chunk['text'], chunk['context'],
                             vector_literal(raw_vec), vector_literal(context_vec)))
    print(f"Stored {len(chunks)} chunks and both embeddings in PostgreSQL.")


def search(implementation, question, mode, top_k, candidates):
    contextual = mode.startswith("context-") or mode == "rerank"
    need_dense = mode not in ("bm25", "context-bm25")
    need_bm25 = mode not in ("dense", "context-dense")
    with open_db() as conn:
        rows = conn.execute("SELECT id, title, text, context FROM lab_chunks ORDER BY id").fetchall()
        if not rows:
            raise ValueError("No chunks found. Run ingest first.")
        dense = []
        if need_dense:
            vector = vector_literal(embed([question])[0])
            column = "contextual_vector" if contextual else "raw_vector"  # fixed choices, not user input
            dense_rows = conn.execute(f"SELECT id, 1 - ({column} <=> %s::vector) AS score "
                                      f"FROM lab_chunks ORDER BY {column} <=> %s::vector, id LIMIT %s",
                                      (vector, vector, candidates)).fetchall()
            dense = [(row['id'], row['score']) for row in dense_rows]
    lexical = implementation.bm25(question, rows, contextual)[:candidates] if need_bm25 else []
    if need_dense and need_bm25:
        ranked = implementation.fuse([dense, lexical])[:candidates]
    else:
        ranked = (dense or lexical)[:candidates]
    by_id = {row['id']: row for row in rows}
    results = [(by_id[chunk_id], score) for chunk_id, score in ranked]
    if mode == "rerank":
        results = implementation.rerank(question, [row for row, _ in results], generate, prompt("rerank"))
    return results[:top_k]


def print_results(results):
    if not results:
        print("No matching chunks.")
    for row, score in results:
        print(f"\n[{row['id']}] score={score:.4f} | {row['title']}\nContext: {row['context']}\nPassage: {row['text']}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--impl", choices=["starter", "solution"], default="solution", help="Choose whose functions run")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("split")
    sub.add_parser("ingest")
    for command in ("search", "answer", "evaluate"):
        p = sub.add_parser(command)
        if command != "evaluate":
            p.add_argument("question")
        p.add_argument("--mode", choices=MODES, default="context-hybrid")
        p.add_argument("--top-k", type=int, default=3)
        p.add_argument("--candidates", type=int, default=6)
    args = parser.parse_args()
    implementation = importlib.import_module(args.impl)
    if args.command == "split":
        for chunk in load_chunks(implementation):
            print(f"[{chunk['id']}] {chunk['text']}")
    elif args.command == "ingest":
        ingest(implementation)
    else:
        if args.top_k < 1 or args.candidates < args.top_k:
            parser.error("--candidates must be at least --top-k, and --top-k must be positive")
        if args.command == "evaluate":
            started = time.perf_counter()
            cases = json.loads((ROOT / "data/evaluation.json").read_text(encoding="utf-8"))
            total_recall = hits = 0
            for case in cases:
                results = search(implementation, case['question'], args.mode, args.top_k, args.candidates)
                found = {row['id'] for row, _ in results}
                expected = set(case['relevant'])
                recall = len(found & expected) / len(expected)
                total_recall += recall
                hits += bool(found & expected)
                print(f"{'HIT ' if recall else 'MISS'} {case['question']} | expected {sorted(expected)} | got {[row['id'] for row, _ in results]}", flush=True)
            print(f"Recall@{args.top_k}: {total_recall / len(cases):.3f}; Hit rate@{args.top_k}: {hits / len(cases):.3f} ({len(cases)} questions)")
            print(f"Evaluation time: {time.perf_counter() - started:.2f} seconds")
        else:
            results = search(implementation, args.question, args.mode, args.top_k, args.candidates)
            print_results(results)
            if args.command == "answer":
                evidence = "\n\n".join(f"[{row['id']}] Context: {row['context']}\nOriginal passage: {row['text']}" for row, _ in results)
                print("\nAnswer:\n" + generate(prompt("answer").format(question=args.question, evidence=evidence or "No evidence retrieved.")))


if __name__ == "__main__":
    main()
