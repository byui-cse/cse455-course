"""Local Ollama chat client that lets the model call tools on an MCP server."""

import asyncio
import json
import sys
from pathlib import Path
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from ollama import AsyncClient


HERE = Path(__file__).resolve().parent
MODEL = "qwen3:1.7b"
OLLAMA_URL = "http://127.0.0.1:11435"
MAX_TOOL_ROUNDS = 3
SYSTEM_PROMPT = """You help students find BYU-Idaho campus services and official City of Rexburg information.
Choose search_campus_resources for university services such as tutoring, advising,
health, counseling, financial aid, and technology support. Choose
search_rexburg_information for City of Rexburg utilities, billing, garbage, or parking
rules and permits. Base specific details on tool results and include the official link.
If neither directory has a match, say so. For campus help, suggest contacting the
BYU-Idaho Support Center at ask@byui.edu or 208-496-1411. Do not invent hours or
eligibility details. For emergencies, tell the student to call 911. For an after-hours
mental health crisis, mention call/text 988.
"""


def tool_specs(mcp_tools: list[Any]) -> list[dict[str, Any]]:
    return [
        {
            "type": "function",
            "function": {
                "name": tool.name,
                "description": tool.description or "",
                "parameters": tool.inputSchema,
            },
        }
        for tool in mcp_tools
    ]


def content_as_text(result: Any) -> str:
    pieces = [item.text for item in result.content if getattr(item, "text", None)]
    return "\n".join(pieces) if pieces else "The tool returned no text."


async def ask(session: ClientSession, model_client: AsyncClient, prompt: str, tools: list[dict[str, Any]]) -> str:
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]

    for _ in range(MAX_TOOL_ROUNDS):
        response = await model_client.chat(model=MODEL, messages=messages, tools=tools)
        assistant_message = response.message
        if not assistant_message.tool_calls:
            return assistant_message.content or "I couldn't produce a response."

        messages.append(assistant_message.model_dump(exclude_none=True))
        for tool_call in assistant_message.tool_calls:
            name = tool_call.function.name
            arguments = tool_call.function.arguments
            print(f"\n[MCP call] {name}({json.dumps(arguments, ensure_ascii=False)})")
            result = await session.call_tool(name, arguments=arguments)
            messages.append(
                {
                    "role": "tool",
                    "tool_name": name,
                    "content": content_as_text(result),
                }
            )

    return "I reached the tool-call limit before finishing. Try a narrower question."


async def main() -> None:
    server_params = StdioServerParameters(
        command=sys.executable,
        args=[str(HERE / "server.py")],
        cwd=str(HERE),
    )
    model_client = AsyncClient(host=OLLAMA_URL)

    async with stdio_client(server_params) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            listed = await session.list_tools()
            tools = tool_specs(listed.tools)
            print("Connected to MCP server. Available tools:")
            for tool in listed.tools:
                print(f"  - {tool.name}: {tool.description}")
            print("\nAsk about a BYU-Idaho service. Type 'quit' to exit.")

            while True:
                try:
                    prompt = input("\nYou: ").strip()
                except (EOFError, KeyboardInterrupt):
                    print()
                    break
                if prompt.lower() in {"quit", "exit"}:
                    break
                if not prompt:
                    continue
                try:
                    answer = await ask(session, model_client, prompt, tools)
                    print(f"\nAssistant: {answer}")
                except Exception as exc:
                    print(f"\nCould not complete the request: {exc}")
                    print("Check that Ollama is running and the model has been downloaded.")


if __name__ == "__main__":
    asyncio.run(main())
