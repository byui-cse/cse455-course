"""MCP server exposing a searchable, locally stored campus resource directory."""

import json
import re
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP


HERE = Path(__file__).resolve().parent
DATA_PATH = HERE / "campus_resources.json"
REXBURG_DATA_PATH = HERE / "rexburg_information.json"
mcp = FastMCP("BYU-Idaho and Rexburg Resources")


def load_resources() -> list[dict[str, Any]]:
    with DATA_PATH.open(encoding="utf-8") as resource_file:
        return json.load(resource_file)


def load_rexburg_information() -> list[dict[str, Any]]:
    with REXBURG_DATA_PATH.open(encoding="utf-8") as info_file:
        return json.load(info_file)


def words(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", text.lower()))


@mcp.tool()
def search_campus_resources(query: str, limit: int = 3) -> str:
    """Find BYU-Idaho student services relevant to a student's need.

    Args:
        query: Describe the service or help the student is looking for.
        limit: Maximum number of matching resources to return (1-5).
    """
    query_words = words(query)
    if not query_words:
        return json.dumps({"results": [], "message": "Enter a few words describing the help you need."})

    limit = max(1, min(limit, 5))
    results = []
    for resource in load_resources():
        name_words = words(resource["name"])
        keyword_words = words(" ".join(resource["keywords"]))
        detail_words = words(
            " ".join([resource["description"], *resource["services"], resource["category"]])
        )
        score = 4 * len(query_words & name_words)
        score += 3 * len(query_words & keyword_words)
        score += len(query_words & detail_words)
        if score:
            results.append((score, resource))

    results.sort(key=lambda item: (-item[0], item[1]["name"]))
    matches = [resource for _, resource in results[:limit]]
    return json.dumps(
        {
            "results": matches,
            "message": "" if matches else "No matching resource was found in this directory.",
        },
        ensure_ascii=False,
    )


@mcp.tool()
def search_rexburg_information(query: str, limit: int = 2) -> str:
    """Search official City of Rexburg information about utilities or parking.

    Args:
        query: Describe the Rexburg city information you need, such as paying a utility bill or parking near campus.
        limit: Maximum number of matching topics to return (1-2).
    """
    query_words = words(query)
    if not query_words:
        return json.dumps({"results": [], "message": "Enter a few words describing the Rexburg information you need."})

    limit = max(1, min(limit, 2))
    results = []
    for item in load_rexburg_information():
        name_words = words(item["name"])
        keyword_words = words(" ".join(item["keywords"]))
        detail_words = words(" ".join([item["topic"], item["description"], *item["details"]]))
        score = 4 * len(query_words & name_words)
        score += 3 * len(query_words & keyword_words)
        score += len(query_words & detail_words)
        if score:
            results.append((score, item))

    results.sort(key=lambda item: (-item[0], item[1]["name"]))
    matches = [item for _, item in results[:limit]]
    return json.dumps(
        {
            "results": matches,
            "message": "" if matches else "No matching Rexburg topic was found in this directory.",
        },
        ensure_ascii=False,
    )


if __name__ == "__main__":
    mcp.run(transport="stdio")
